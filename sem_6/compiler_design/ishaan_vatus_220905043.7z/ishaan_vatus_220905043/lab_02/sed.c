#include <stdio.h>
#include <stdbool.h>
#define TAB 9
#define SPACE 32
int main(int argc, char **argv)
{
	FILE *fp = fopen(argv[1], "r");
	FILE *san = fopen("sanitized", "w");
	char ch;
	bool flag = false;
	while ((ch = fgetc(fp)) != EOF) {
		if ((ch == SPACE || ch == TAB) && !flag) {
			fputc(SPACE, san);
			flag = true;
		}
		else if ((ch == SPACE || ch == TAB) && flag) {
			continue;
		}
		else {
			fputc(ch, san);
			flag = false;
		}
	}
}